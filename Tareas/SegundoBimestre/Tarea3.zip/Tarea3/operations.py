
def addition(a : int, b : int):
    return a + b

def minus(a : int, b : int):
    return a - b

def multiplication(a : int, b : int):
    return a * b

def division(a : int, b : int):
    return a / b
    